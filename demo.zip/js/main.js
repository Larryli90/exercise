var menuBar = document.getElementsByClassName('fa-bars')[0];
menuBar.addEventListener('click', displayMenu);
function displayMenu(){
    var mask = document.getElementsByClassName('mask')[0];
    mask.style.cssText = "display:block";
}

var close = document.getElementsByClassName('close')[0];
close.addEventListener('click', disappearMenu);
function disappearMenu(){
    var mask = document.getElementsByClassName('mask')[0];
    mask.style.cssText = "display:none";
}

var collapseBtn = document.getElementsByClassName('collapse-btn');
for (var i=0; i<collapseBtn.length; i++){
    collapseBtn[i].onclick = function(){
        var span = this.getElementsByTagName('span')[0];
        if(this.getAttribute('aria-expanded') == 'true'){
            span.innerHTML = '-';
        }else{
            span.innerHTML = '+';
        }
    };
}

$('#product,#best').owlCarousel({
    dots:false,
    loop:true,
    margin:10,
    nav:true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:5,
            loop:false
        }
    }
})

$('#review').owlCarousel({
    stagePadding: 100,
    margin:10,
    nav:true,
    loop:true,
    responsive:{
        0:{
            items:1
        },
        700:{
            items:2
        },
        1000:{
            items:3
        }
    }
})